import React from 'react';
import { motion } from 'motion/react';
import { ChevronDown, Github, Instagram, Mail, Terminal } from 'lucide-react';
import { AVATAR_IMAGE_URL } from '../constants';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-6 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 cyber-grid opacity-20"></div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyber-accent/10 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '1s' }}></div>

      <div className="relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="mb-8 relative inline-block"
        >
          <div className="w-32 h-32 rounded-full p-1 bg-gradient-to-tr from-cyber-accent to-blue-500 animate-spin-slow">
            <div className="w-full h-full rounded-full overflow-hidden bg-cyber-black p-1">
              <img 
                src={AVATAR_IMAGE_URL} 
                alt="Reyga Wahyu Avatar" 
                className="w-full h-full object-cover rounded-full grayscale hover:grayscale-0 transition-all duration-500"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="absolute -bottom-2 -right-2 bg-cyber-accent text-black p-2 rounded-full shadow-lg shadow-cyber-accent/50">
            <Terminal size={14} />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-6 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm"
        >
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-white/60">System Initialized // 2026</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-6xl md:text-8xl lg:text-9xl font-display font-bold tracking-tighter mb-8 leading-none"
        >
          REYGA <span className="text-cyber-accent text-glow">WAHYU</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto font-mono mb-12"
        >
          Full Stack Developer • IoT Enthusiast • Cyber Security Student
          <br />
          <span className="text-sm text-white/30 mt-2 block italic">Born in Kutoarjo, 2009. Exploring the digital frontier since 2021.</span>
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-wrap items-center justify-center gap-6"
        >
          <a href="#contact" className="px-8 py-4 bg-cyber-accent text-black font-bold rounded-xl hover:scale-105 transition-transform shadow-lg shadow-cyber-accent/20">
            Initialize Contact
          </a>
          <div className="flex items-center gap-4">
            <a href="https://instagram.com/rudymayer.fr" target="_blank" rel="noopener noreferrer" className="p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
              <Instagram size={24} />
            </a>
            <a href="mailto:buypristine@gmail.com" className="p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
              <Mail size={24} />
            </a>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-[10px] font-mono uppercase tracking-widest text-white/20">Scroll to Explore</span>
        <ChevronDown className="text-white/20 animate-bounce" size={20} />
      </motion.div>
    </section>
  );
}
