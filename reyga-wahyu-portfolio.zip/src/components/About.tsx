import React from 'react';
import { motion } from 'motion/react';
import { User, School, Calendar, MapPin, History } from 'lucide-react';
import { PROFILE_IMAGE_URL } from '../constants';

export default function About() {
  return (
    <section id="about" className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-3xl overflow-hidden glass-panel p-2">
              <img 
                src={PROFILE_IMAGE_URL} 
                alt="Reyga Wahyu Nur Hidayat" 
                className="w-full h-full object-cover rounded-2xl grayscale hover:grayscale-0 transition-all duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-cyber-black via-transparent to-transparent"></div>
              <div className="absolute bottom-8 left-8 right-8">
                <div className="flex items-center gap-3 mb-2">
                  <div className="h-2 w-2 rounded-full bg-cyber-accent animate-ping"></div>
                  <span className="text-xs font-mono text-cyber-accent uppercase tracking-widest">Active Status</span>
                </div>
                <h3 className="text-3xl font-display font-bold">Reyga Wahyu N.H.</h3>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-4 -right-4 w-24 h-24 border-t-2 border-r-2 border-cyber-accent/30"></div>
            <div className="absolute -bottom-4 -left-4 w-24 h-24 border-b-2 border-l-2 border-cyber-accent/30"></div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-5xl font-display font-bold tracking-tighter mb-6">Identity Profile</h2>
              <p className="text-white/60 font-mono leading-relaxed">
                A highly motivated student specializing in Computer and Network Engineering. 
                Self-taught coder with a passion for building integrated digital solutions.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="glass-panel p-4 flex items-start gap-4">
                <div className="p-2 rounded-lg bg-white/5 text-cyber-accent">
                  <MapPin size={20} />
                </div>
                <div>
                  <p className="text-[10px] font-mono text-white/40 uppercase">Origin</p>
                  <p className="text-sm font-bold">Kutoarjo, Purworejo</p>
                </div>
              </div>

              <div className="glass-panel p-4 flex items-start gap-4">
                <div className="p-2 rounded-lg bg-white/5 text-cyber-accent">
                  <Calendar size={20} />
                </div>
                <div>
                  <p className="text-[10px] font-mono text-white/40 uppercase">Born</p>
                  <p className="text-sm font-bold">28 March 2009</p>
                </div>
              </div>

              <div className="glass-panel p-4 flex items-start gap-4">
                <div className="p-2 rounded-lg bg-white/5 text-cyber-accent">
                  <School size={20} />
                </div>
                <div>
                  <p className="text-[10px] font-mono text-white/40 uppercase">Education</p>
                  <p className="text-sm font-bold">SMK Bina Teknika Cileungsi</p>
                  <p className="text-[10px] text-white/40">TKJ (Computer & Network Eng.)</p>
                </div>
              </div>

              <div className="glass-panel p-4 flex items-start gap-4">
                <div className="p-2 rounded-lg bg-white/5 text-cyber-accent">
                  <History size={20} />
                </div>
                <div>
                  <p className="text-[10px] font-mono text-white/40 uppercase">Journey</p>
                  <p className="text-sm font-bold">Coding since 2022</p>
                  <p className="text-[10px] text-white/40">Digital interest since 2021</p>
                </div>
              </div>
            </div>

            <div className="pt-6">
              <div className="flex items-center gap-4 p-4 rounded-2xl bg-cyber-accent/5 border border-cyber-accent/20">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-cyber-accent flex items-center justify-center text-black">
                  <User size={24} />
                </div>
                <p className="text-sm italic text-white/80">
                  "I am a person who likes to find new things and will continue to pursue them until I achieve what I want."
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
