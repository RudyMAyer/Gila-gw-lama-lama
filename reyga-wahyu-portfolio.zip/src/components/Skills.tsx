import React from 'react';
import { motion } from 'motion/react';
import { Terminal, Cpu, Shield, Globe, Code, Layers } from 'lucide-react';

const skills = [
  { name: 'Basic IoT', icon: Cpu, level: 75, color: 'text-emerald-400' },
  { name: 'Full Stack Dev', icon: Code, level: 85, color: 'text-blue-400' },
  { name: 'Cyber Security', icon: Shield, level: 65, color: 'text-red-400' },
  { name: 'Networking', icon: Globe, level: 80, color: 'text-purple-400' },
  { name: 'Computerization', icon: Layers, level: 70, color: 'text-amber-400' },
  { name: 'English', icon: Terminal, level: 90, color: 'text-indigo-400' },
];

export default function Skills() {
  return (
    <section id="skills" className="py-20 px-6 bg-cyber-gray/50">
      <div className="max-w-6xl mx-auto">
        <div className="mb-16">
          <h2 className="text-5xl font-display font-bold tracking-tighter mb-4">Core Matrix</h2>
          <div className="h-1 w-20 bg-cyber-accent"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skills.map((skill, i) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="glass-panel p-6 glow-border group"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className={`p-3 rounded-xl bg-white/5 ${skill.color} group-hover:scale-110 transition-transform`}>
                  <skill.icon size={24} />
                </div>
                <div>
                  <h3 className="font-display font-bold text-xl">{skill.name}</h3>
                  <p className="text-xs font-mono text-white/40 uppercase tracking-widest">Skill Module</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-white/60">Proficiency</span>
                  <span className="text-cyber-accent">{skill.level}%</span>
                </div>
                <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.level}%` }}
                    transition={{ duration: 1, delay: 0.5 }}
                    viewport={{ once: true }}
                    className="h-full bg-cyber-accent shadow-[0_0_10px_rgba(16,185,129,0.5)]"
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 p-6 glass-panel border-dashed border-white/10">
          <div className="flex flex-wrap gap-4 items-center justify-center text-white/50 font-mono text-sm">
            <span>Spanish (Basic)</span>
            <span className="text-cyber-accent">•</span>
            <span>Photography</span>
            <span className="text-cyber-accent">•</span>
            <span>Videography</span>
            <span className="text-cyber-accent">•</span>
            <span>Digital Illustration</span>
          </div>
        </div>
      </div>
    </section>
  );
}
