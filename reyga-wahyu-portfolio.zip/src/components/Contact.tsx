import React from 'react';
import { motion } from 'motion/react';
import { Instagram, Phone, Mail, MapPin, ExternalLink } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-20 px-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full cyber-grid opacity-10 pointer-events-none"></div>
      
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h2 className="text-6xl font-display font-bold tracking-tighter mb-6">Connect With Me</h2>
          <p className="text-white/60 max-w-xl mx-auto font-mono">
            Always looking for new challenges and collaborations. Reach out through any of these channels.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <a 
            href="https://instagram.com/rudymayer.fr" 
            target="_blank" 
            rel="noopener noreferrer"
            className="glass-panel p-8 flex flex-col items-center gap-4 glow-border group"
          >
            <div className="p-4 rounded-full bg-white/5 text-pink-500 group-hover:bg-pink-500 group-hover:text-white transition-all">
              <Instagram size={32} />
            </div>
            <span className="font-display font-bold">@rudymayer.fr</span>
            <span className="text-xs font-mono text-white/40">Instagram</span>
          </a>

          <a 
            href="tel:+6288994380674" 
            className="glass-panel p-8 flex flex-col items-center gap-4 glow-border group"
          >
            <div className="p-4 rounded-full bg-white/5 text-cyber-accent group-hover:bg-cyber-accent group-hover:text-black transition-all">
              <Phone size={32} />
            </div>
            <span className="font-display font-bold">+62 889-9438-0674</span>
            <span className="text-xs font-mono text-white/40">Phone</span>
          </a>

          <a 
            href="mailto:buypristine@gmail.com" 
            className="glass-panel p-8 flex flex-col items-center gap-4 glow-border group"
          >
            <div className="p-4 rounded-full bg-white/5 text-blue-400 group-hover:bg-blue-400 group-hover:text-white transition-all">
              <Mail size={32} />
            </div>
            <span className="font-display font-bold">buypristine@gmail.com</span>
            <span className="text-xs font-mono text-white/40">Email</span>
          </a>
        </div>

        <div className="mt-20 pt-12 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2 text-white/40 font-mono text-sm">
            <MapPin size={16} />
            <span>Kutoarjo, Purworejo • Cileungsi, Bogor</span>
          </div>
          
          <div className="text-white/20 font-mono text-xs">
            © {new Date().getFullYear()} REYGA WAHYU NUR HIDAYAT. ALL RIGHTS RESERVED.
          </div>
        </div>
      </div>
    </section>
  );
}
