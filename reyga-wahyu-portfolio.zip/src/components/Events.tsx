import React from 'react';
import { motion } from 'motion/react';
import { Calendar, Award, Briefcase } from 'lucide-react';

const events = [
  {
    title: "Booth Student Camp PT. Solusi Intek Indonesia",
    date: "Mid 2025",
    role: "Programmer & Microcontroller",
    description: "Advanced implementation of IoT solutions and system architecture.",
    status: "Latest"
  },
  {
    title: "Booth Student Camp PT. Solusi Intek Indonesia",
    date: "Early 2025",
    role: "Programmer & Microcontroller",
    description: "Developed integrated systems for industrial monitoring.",
    status: "Completed"
  },
  {
    title: "Booth Student Camp PT. Solusi Intek Indonesia",
    date: "2024",
    role: "Programmer & Microcontroller",
    description: "First participation, focusing on basic microelectronics and coding.",
    status: "Completed"
  }
];

export default function Events() {
  return (
    <section id="events" className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <h2 className="text-5xl font-display font-bold tracking-tighter mb-4">Event Logs</h2>
            <p className="text-white/60 font-mono">Professional milestones and field experience.</p>
          </div>
          <div className="flex items-center gap-3 px-4 py-2 glass-panel border-cyber-accent/30">
            <Award className="text-cyber-accent" size={20} />
            <span className="text-sm font-bold">PT. Solusi Intek Indonesia</span>
          </div>
        </div>

        <div className="space-y-6">
          {events.map((event, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="glass-panel p-8 flex flex-col md:flex-row gap-8 items-start md:items-center glow-border"
            >
              <div className="flex-shrink-0 w-full md:w-48">
                <div className="flex items-center gap-2 text-cyber-accent mb-2">
                  <Calendar size={16} />
                  <span className="font-mono text-sm font-bold">{event.date}</span>
                </div>
                <div className={`inline-block px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                  event.status === 'Latest' ? 'bg-cyber-accent text-black' : 'bg-white/10 text-white/50'
                }`}>
                  {event.status}
                </div>
              </div>

              <div className="flex-1">
                <h3 className="text-2xl font-display font-bold mb-2">{event.title}</h3>
                <div className="flex items-center gap-2 text-white/60 mb-4">
                  <Briefcase size={16} />
                  <span className="text-sm font-medium">{event.role}</span>
                </div>
                <p className="text-white/40 text-sm leading-relaxed">
                  {event.description}
                </p>
              </div>

              <div className="hidden lg:block">
                <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center text-white/20">
                  {i + 1}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
