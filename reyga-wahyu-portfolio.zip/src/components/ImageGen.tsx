import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Image as ImageIcon, Loader2, Download, Sparkles } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export default function ImageGen() {
  const [prompt, setPrompt] = useState('');
  const [size, setSize] = useState<"1K" | "2K" | "4K">("1K");
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim() || isLoading) return;
    setIsLoading(true);
    setImageUrl(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
      const response = await ai.models.generateContent({
        model: "gemini-3-pro-image-preview",
        contents: {
          parts: [{ text: `Cyberpunk style, high quality, digital art: ${prompt}` }]
        },
        config: {
          imageConfig: {
            aspectRatio: "1:1",
            imageSize: size
          }
        }
      });

      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          setImageUrl(`data:image/png;base64,${part.inlineData.data}`);
          break;
        }
      }
    } catch (error) {
      console.error("Image Gen Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="creative" className="py-20 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <Sparkles className="text-cyber-accent" size={28} />
          <h2 className="text-4xl font-display font-bold tracking-tighter">AI Creative Lab</h2>
        </div>

        <div className="glass-panel p-8">
          <p className="text-white/60 mb-6 font-mono text-sm uppercase tracking-widest">
            // Generate custom cyber-art using Gemini 3 Pro
          </p>
          
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="flex-1">
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe a cybernetic landscape..."
                className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 text-white focus:outline-none focus:border-cyber-accent/50 transition-colors"
              />
            </div>
            <div className="flex gap-2">
              {(["1K", "2K", "4K"] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setSize(s)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                    size === s 
                      ? 'bg-cyber-accent text-black' 
                      : 'bg-white/5 text-white/50 border border-white/10 hover:bg-white/10'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
            <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="bg-cyber-accent text-black px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:scale-105 transition-transform disabled:opacity-50 disabled:hover:scale-100"
            >
              {isLoading ? <Loader2 className="animate-spin" size={20} /> : <ImageIcon size={20} />}
              Generate
            </button>
          </div>

          <div className="aspect-square w-full max-w-md mx-auto relative rounded-2xl overflow-hidden bg-white/5 border border-white/10 flex items-center justify-center">
            {imageUrl ? (
              <>
                <img src={imageUrl} alt="Generated Art" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                <a 
                  href={imageUrl} 
                  download="cyber-art.png"
                  className="absolute bottom-4 right-4 p-3 bg-black/50 backdrop-blur-md text-white rounded-full hover:bg-cyber-accent hover:text-black transition-all"
                >
                  <Download size={20} />
                </a>
              </>
            ) : (
              <div className="text-center p-8">
                {isLoading ? (
                  <div className="flex flex-col items-center gap-4">
                    <Loader2 className="animate-spin text-cyber-accent" size={48} />
                    <p className="text-white/40 font-mono text-sm animate-pulse">Synthesizing pixels...</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-4">
                    <ImageIcon size={48} className="text-white/10" />
                    <p className="text-white/30 font-mono text-sm italic">Enter a prompt to begin generation</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
