import React from 'react';
import { motion } from 'motion/react';
import { Mountain, Dumbbell, Book, Camera, Video, Palette, Zap } from 'lucide-react';

const hobbies = [
  { name: 'Heavy Sports', icon: Dumbbell, desc: 'Pushing physical limits' },
  { name: 'Hiking', icon: Mountain, desc: 'Conquering peaks' },
  { name: 'Reading', icon: Book, desc: 'Expanding knowledge' },
  { name: 'Drawing', icon: Palette, desc: 'Visual expression' },
  { name: 'Photography', icon: Camera, desc: 'Capturing moments' },
  { name: 'Videography', icon: Video, desc: 'Storytelling in motion' },
];

export default function Hobbies() {
  return (
    <section id="hobbies" className="py-20 px-6 bg-cyber-gray/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-display font-bold tracking-tighter mb-4">Beyond The Code</h2>
          <p className="text-white/60 font-mono">Personal interests and creative outlets.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {hobbies.map((hobby, i) => (
            <motion.div
              key={hobby.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              viewport={{ once: true }}
              className="glass-panel p-6 flex flex-col items-center text-center gap-4 hover:bg-cyber-accent/10 transition-colors group cursor-default"
            >
              <div className="p-4 rounded-2xl bg-white/5 text-cyber-accent group-hover:scale-110 transition-transform">
                <hobby.icon size={32} />
              </div>
              <div>
                <h3 className="font-display font-bold text-sm mb-1">{hobby.name}</h3>
                <p className="text-[10px] font-mono text-white/30 uppercase tracking-tighter">{hobby.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 glass-panel p-8 md:p-12 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 text-cyber-accent/10 group-hover:text-cyber-accent/20 transition-colors">
            <Zap size={120} />
          </div>
          <div className="relative z-10 max-w-2xl">
            <h3 className="text-3xl font-display font-bold mb-6 italic">"A person who loves to find new things and will continue to pursue them until the desired thing is achieved."</h3>
            <div className="flex items-center gap-4">
              <div className="h-px w-12 bg-cyber-accent"></div>
              <span className="font-mono text-sm uppercase tracking-widest text-white/60">The Philosophy</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
