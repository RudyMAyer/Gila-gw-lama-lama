export const PROFILE_IMAGE_URL = "https://picsum.photos/seed/reyga-cyber/800/1000";
export const AVATAR_IMAGE_URL = "https://picsum.photos/seed/reyga-avatar/200/200";
