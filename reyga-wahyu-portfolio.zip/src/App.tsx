import React, { useEffect } from 'react';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Events from './components/Events';
import Hobbies from './components/Hobbies';
import Contact from './components/Contact';
import AIChat from './components/AIChat';
import ImageGen from './components/ImageGen';

export default function App() {
  console.log("App component rendering");
  useEffect(() => {
    console.log("App mounted");
    // Smooth scroll behavior for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        if (targetId) {
          const targetElement = document.querySelector(targetId);
          if (targetElement) {
            targetElement.scrollIntoView({
              behavior: 'smooth'
            });
          }
        }
      });
    });
  }, []);

  return (
    <div className="min-h-screen bg-cyber-black selection:bg-cyber-accent selection:text-black">
      {/* Navigation (Optional/Simple) */}
      <nav className="fixed top-0 left-0 w-full z-40 px-6 py-4 flex justify-between items-center bg-cyber-black/50 backdrop-blur-md border-b border-white/5">
        <div className="font-display font-bold text-xl tracking-tighter">
          RW<span className="text-cyber-accent">.</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-[10px] font-mono uppercase tracking-widest text-white/40">
          <a href="#about" className="hover:text-cyber-accent transition-colors">Identity</a>
          <a href="#skills" className="hover:text-cyber-accent transition-colors">Matrix</a>
          <a href="#events" className="hover:text-cyber-accent transition-colors">Logs</a>
          <a href="#creative" className="hover:text-cyber-accent transition-colors">Creative</a>
          <a href="#contact" className="hover:text-cyber-accent transition-colors">Connect</a>
        </div>
      </nav>

      <main>
        <Hero />
        <About />
        <Skills />
        <Events />
        <ImageGen />
        <Hobbies />
        <Contact />
      </main>

      {/* Floating AI Assistant */}
      <AIChat />
    </div>
  );
}
