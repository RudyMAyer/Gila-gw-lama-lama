import { GoogleGenAI, Type, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const chatModel = "gemini-3.1-pro-preview";
export const flashModel = "gemini-2.5-flash-lite";
export const imageModel = "gemini-3-pro-image-preview";

export async function generatePortfolioResponse(prompt: string, model: string = flashModel) {
  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        systemInstruction: "You are an AI assistant integrated into Reyga Wahyu Nur Hidayat's portfolio. Reyga is a 16-year-old student at SMK Bina Teknika Cileungsi majoring in TKJ. He is a self-taught programmer (since 2022), IoT enthusiast, and aspiring cyber security expert. Answer questions about him professionally and with a touch of cyber/tech elegance.",
      }
    });
    return response.text;
  } catch (error) {
    console.error("AI Error:", error);
    return "Error generating response.";
  }
}

export async function generateImage(prompt: string, size: "1K" | "2K" | "4K" = "1K") {
  try {
    const response = await ai.models.generateContent({
      model: imageModel,
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: size
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Image Gen Error:", error);
    return null;
  }
}
